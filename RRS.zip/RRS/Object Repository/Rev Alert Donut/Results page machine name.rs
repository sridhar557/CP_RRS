<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results page machine name</name>
   <tag></tag>
   <elementGuidId>563e5ca9-e06c-4eb3-9170-578f08231c65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-revolution-dashboard/div/div/div[1]/div[1]/app-meta-data-card/div/div/div/div[1]/div[2]/div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-revolution-dashboard/div/div/div[1]/div[1]/app-meta-data-card/div/div/div/div[1]/div[2]/div[1]</value>
   </webElementProperties>
</WebElementEntity>
