<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Dashboard Card</name>
   <tag></tag>
   <elementGuidId>78e1ddb6-0c2a-48d3-8b45-494a92846514</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//app-dashboard-card[@id='[object Object]']/mat-card/mat-card-content/div/div)[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>circle-component green</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>1.74</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[@class=&quot;content dashboard-wrapper&quot;]/app-main[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;main-container&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container&quot;]/mat-sidenav-content[@class=&quot;mat-drawer-content mat-sidenav-content ng-star-inserted&quot;]/div[@class=&quot;content dashboard-wrapper&quot;]/app-executive-dashboard[@class=&quot;ng-star-inserted&quot;]/div[4]/app-dashboard-kpi[1]/div[@class=&quot;kpi-wrapper&quot;]/div[@class=&quot;kpi-container card-wrapper ng-star-inserted&quot;]/span[@class=&quot;card-container dashboard-card-container&quot;]/app-dashboard-card[@id=&quot;[object Object]&quot;]/mat-card[@class=&quot;card mat-card green&quot;]/mat-card-content[@class=&quot;mat-card-content ng-star-inserted&quot;]/div[@class=&quot;circle-container ng-star-inserted&quot;]/div[@class=&quot;circle-component green&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>(//app-dashboard-card[@id='[object Object]']/mat-card/mat-card-content/div/div)[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Updated: Invalid date'])[2]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Number Of Hours Spent On Site'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[3]/span[2]/app-dashboard-card/mat-card/mat-card-content/div/div</value>
   </webElementXpaths>
</WebElementEntity>
