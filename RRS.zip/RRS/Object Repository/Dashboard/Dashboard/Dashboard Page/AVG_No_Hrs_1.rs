<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AVG_No_Hrs_1</name>
   <tag></tag>
   <elementGuidId>39cddb53-dc76-4b1f-a483-0b8f4ee5698c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//app-dashboard-card[@id='1']/mat-card/mat-card-header/div/mat-card-subtitle</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='DAILY DASHBOARD'])[1]/following::mat-card-subtitle[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-subtitle</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-card-subtitle</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Last Updated: Nov 25, 2018 </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DAILY DASHBOARD'])[1]/following::mat-card-subtitle[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//app-dashboard-card[@id='1']/mat-card/mat-card-header/div/mat-card-subtitle</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Number Of Hours Spent On Site'])[1]/following::mat-card-subtitle[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DAILY DASHBOARD'])[1]/following::mat-card-subtitle[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NA'])[1]/preceding::mat-card-subtitle[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='High Frequency Dispatch Stores'])[1]/preceding::mat-card-subtitle[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//mat-card-subtitle</value>
   </webElementXpaths>
</WebElementEntity>
