<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>User Exp Table</name>
   <tag></tag>
   <elementGuidId>f15867a8-7ef6-4423-8ab4-087230d470b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[2]/div/div/app-info-table/div/div[2]/mat-table</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[2]/div/div/app-info-table/div/div[2]/mat-table</value>
   </webElementProperties>
</WebElementEntity>
