<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Unit Life  Dashboard display</name>
   <tag></tag>
   <elementGuidId>6a9a17e8-d88e-4350-8020-ca9772161c70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='UNIT LIFE AND PM ROLLING 365 DAYS'])[1]/following::mat-card[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card mat-card as-component-card</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-klass</name>
      <type>Main</type>
      <value>card</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> BA-03534, 7500 - BCR500  GRAND WAILEA location_onHonolulu HI HNL-003 From Last Preventative Maintenance 7,289,6113,088,2007,289,611Rated At : 200,000 BA-00818, 7000  HY-VEE #1520 location_onBloomington IL BMI-003 From Last Preventative Maintenance 6,939,5989,931,5736,939,598Rated At : 200,000 BA-01892, 7000  AREAS USA - LAX AIRPORT location_onGardena CA LAX-005 From Last Preventative Maintenance 4,099,0434,052,3874,099,043Rated At : 200,000</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[@class=&quot;content dashboard-wrapper&quot;]/app-main[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;main-container&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container&quot;]/mat-sidenav-content[@class=&quot;mat-drawer-content mat-sidenav-content ng-star-inserted&quot;]/div[@class=&quot;content dashboard-wrapper&quot;]/app-executive-dashboard[@class=&quot;ng-star-inserted&quot;]/div[4]/app-dashboard-kpi[1]/div[@class=&quot;kpi-wrapper&quot;]/div[@class=&quot;kpi-container unit-life-container chart-wrapper&quot;]/span[@class=&quot;unit-life&quot;]/app-unit-life[@class=&quot;ng-star-inserted&quot;]/mat-card[@class=&quot;card mat-card as-component-card&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNIT LIFE AND PM ROLLING 365 DAYS'])[1]/following::mat-card[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//app-unit-life/mat-card</value>
   </webElementXpaths>
</WebElementEntity>
