<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Success Ratio By  Store cl</name>
   <tag></tag>
   <elementGuidId>ba8d02db-dea9-4f9f-a9eb-966872d9b9aa</elementGuidId>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>info-table ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Success Ratio By  Store close  Store Intervention Count  Financial Transaction  Success Ratio  AMIGO'S #508 298 3288 90.94% UNITED SUPERMARKET #537 81 3748 97.84% UNITED SUPERMARKET #506 79 4754 98.34% AMIGO'S #510 28 2595 98.92% MARKET STREET #502 65 6033 98.92% MARKET STREET #564 - STORE 34 3222 98.94% MARKET STREET #553 55 5744 99.04% UNITED SUPERMARKET #530 29 3785 99.23% MARKET STREET #526 42 5535 99.24% UNITED SUPERMARKET #529 35 5226 99.33% MARKET STREET #543 32 5345 99.40% MARKET STREET #562 20 3601 99.44% AMIGO'S #503 20 3852 99.48% MARKET STREET #564 - FUEL STATION 9 1874 99.52% MARKET STREET #517 23 5214 99.56% UNITED SUPERMARKET #551 24 5510 99.56% MARKET STREET #565 4 3481 99.89%</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[@class=&quot;content dashboard-wrapper&quot;]/app-main[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;main-container&quot;]/mat-sidenav-container[@class=&quot;mat-drawer-container mat-sidenav-container mat-drawer-transition&quot;]/mat-sidenav-content[@class=&quot;mat-drawer-content mat-sidenav-content ng-star-inserted&quot;]/div[@class=&quot;content dashboard-wrapper&quot;]/app-user-experience-report[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;report-container&quot;]/div[@class=&quot;section&quot;]/div[@class=&quot;info-table ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='touch_app'])[2]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Page 1 of 1'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[3]/div[2]/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
