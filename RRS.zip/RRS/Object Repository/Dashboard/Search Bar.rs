<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search Bar</name>
   <tag></tag>
   <elementGuidId>9e88eaf0-5298-4ac4-833e-9455c935a17c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-expansion-panel-header-0&quot;]/span/mat-panel-title/input</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-expansion-panel-header-0&quot;]/span/mat-panel-title/input</value>
   </webElementProperties>
</WebElementEntity>
