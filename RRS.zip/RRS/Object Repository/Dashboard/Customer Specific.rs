<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>generic for all customers</description>
   <name>Customer Specific</name>
   <tag></tag>
   <elementGuidId>b826e199-c2ec-4bef-848d-f4e3d0d1e552</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=' WESTIN ']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=' WESTIN ']</value>
   </webElementProperties>
</WebElementEntity>
