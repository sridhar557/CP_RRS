<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Bar 1 success ratio</name>
   <tag></tag>
   <elementGuidId>7cb8ab6d-ace4-48ba-ba1e-c9de4b19544f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[2]/div/div/app-info-table/div/div[2]/mat-table/mat-row/mat-cell[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[2]/div/div/app-info-table/div/div[2]/mat-table/mat-row/mat-cell[4]</value>
   </webElementProperties>
</WebElementEntity>
