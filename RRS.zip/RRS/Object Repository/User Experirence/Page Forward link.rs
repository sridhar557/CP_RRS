<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Page Forward link</name>
   <tag></tag>
   <elementGuidId>f707a2cd-f814-407c-812a-01bc9db53a5d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[1]/div/div/app-bar-chart/mat-paginator/div/div[2]/button[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[1]/div/div/app-bar-chart/mat-paginator/div/div[2]/button[2]/span</value>
   </webElementProperties>
</WebElementEntity>
