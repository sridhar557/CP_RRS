<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Pagination details</name>
   <tag></tag>
   <elementGuidId>d27d2c55-a2ed-4c1d-99aa-55a734ea5f7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[1]/div/div/app-bar-chart/mat-paginator/div/div[2]/div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-user-experience-report/div[3]/div[2]/div[1]/div/div/app-bar-chart/mat-paginator/div/div[2]/div</value>
   </webElementProperties>
</WebElementEntity>
