<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Execution Status updated</name>
   <tag></tag>
   <elementGuidId>90bbb2e2-b9ee-498f-afd9-6a7bd404de9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span/span[2]/span[2])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span/span[2]/span[2])[1]</value>
   </webElementProperties>
</WebElementEntity>
