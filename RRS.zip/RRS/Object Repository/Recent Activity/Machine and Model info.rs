<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Machine and Model info</name>
   <tag></tag>
   <elementGuidId>d5530842-3acd-4801-8207-194f7954f46f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//app-meta-data-card/div/div/div/div/div[2]/div)[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//app-meta-data-card/div/div/div/div/div[2]/div)[1]</value>
   </webElementProperties>
</WebElementEntity>
