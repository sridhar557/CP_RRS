<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>First Activity name</name>
   <tag></tag>
   <elementGuidId>ef0eec5c-10ce-4ff3-a704-d495af8756b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-tab-content-11-0&quot;]/div/mat-card-content/div/div[1]/span[2]/span[1]/span[2]/span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-tab-content-11-0&quot;]/div/mat-card-content/div/div[1]/span[2]/span[1]/span[2]/span[1]</value>
   </webElementProperties>
</WebElementEntity>
