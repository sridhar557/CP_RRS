<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>First Activity Status</name>
   <tag></tag>
   <elementGuidId>75cc7290-d65f-4636-bd57-c5e73529d2b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-tab-content-20-0&quot;]/div/mat-card-content/div/div[1]/span[2]/span[1]/span[2]/span[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-tab-content-20-0&quot;]/div/mat-card-content/div/div[1]/span[2]/span[1]/span[2]/span[2]</value>
   </webElementProperties>
</WebElementEntity>
