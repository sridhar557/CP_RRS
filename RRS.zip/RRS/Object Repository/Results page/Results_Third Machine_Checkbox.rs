<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>3rd Checkbox</description>
   <name>Results_Third Machine_Checkbox</name>
   <tag></tag>
   <elementGuidId>ceb5d0e4-fc87-41af-b8d7-d1bcb98a3561</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-checkbox-814&quot;]/label/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-checkbox-814&quot;]/label/div</value>
   </webElementProperties>
</WebElementEntity>
