<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_Second machine_Checkbox</name>
   <tag></tag>
   <elementGuidId>8bb172ec-1a8c-4224-a0d2-5bdf253c13a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-checkbox-813&quot;]/label/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-checkbox-813&quot;]/label/div</value>
   </webElementProperties>
</WebElementEntity>
