<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_First Machine_BA</name>
   <tag></tag>
   <elementGuidId>eabbac78-7c87-42bc-9dde-4d801e6b1635</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-search-result/div/app-search-result-list/section/div/mat-card/div[2]/div/div[1]/div[4]/span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-search-result/div/app-search-result-list/section/div/mat-card/div[2]/div/div[1]/div[4]/span</value>
   </webElementProperties>
</WebElementEntity>
