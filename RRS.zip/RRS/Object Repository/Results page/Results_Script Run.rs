<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_Script Run</name>
   <tag></tag>
   <elementGuidId>43f62cfe-64d9-4ef5-a4ba-641ee2db6ac0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()[contains(.,'Run Script')]]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()[contains(.,'Run Script')]]</value>
   </webElementProperties>
</WebElementEntity>
