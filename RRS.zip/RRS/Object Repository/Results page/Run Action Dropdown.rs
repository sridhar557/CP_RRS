<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Run Action Dropdown</name>
   <tag></tag>
   <elementGuidId>f9fbf7e7-4d58-4de6-a10e-aa0091c36216</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-search-result/div/app-search-result-list/section/div/mat-card-subtitle/span/button[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/app-root/div[1]/app-main/div/mat-sidenav-container/mat-sidenav-content/div/app-search-result/div/app-search-result-list/section/div/mat-card-subtitle/span/button[3]</value>
   </webElementProperties>
</WebElementEntity>
