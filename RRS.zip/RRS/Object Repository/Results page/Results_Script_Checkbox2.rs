<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_Script_Checkbox2</name>
   <tag></tag>
   <elementGuidId>e15f09cf-ca2f-416a-bce3-077caed388b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Scripts'])[2]/following::div[14]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scripts'])[2]/following::div[14]</value>
   </webElementProperties>
</WebElementEntity>
