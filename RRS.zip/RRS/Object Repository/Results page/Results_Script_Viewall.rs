<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_Script_Viewall</name>
   <tag></tag>
   <elementGuidId>f7677201-88d8-429b-8118-cb54e6942875</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()[contains(.,' ViewAll ( ')]]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()[contains(.,' ViewAll ( ')]]</value>
   </webElementProperties>
</WebElementEntity>
