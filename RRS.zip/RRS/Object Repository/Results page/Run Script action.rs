<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Run Script action</name>
   <tag></tag>
   <elementGuidId>9d3fd718-3c3d-4f3b-a61d-0cc8518ec3e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()[contains(.,'Run Script')]]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()[contains(.,'Run Script')]]</value>
   </webElementProperties>
</WebElementEntity>
