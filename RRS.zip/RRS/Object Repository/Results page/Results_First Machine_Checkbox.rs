<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Results_First Machine_Checkbox</name>
   <tag></tag>
   <elementGuidId>f777e2b6-3674-4702-8b3c-fc414a83b503</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;mat-checkbox-812&quot;]/label/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;mat-checkbox-812&quot;]/label/div</value>
   </webElementProperties>
</WebElementEntity>
