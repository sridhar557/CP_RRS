<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deploy Package</name>
   <tag></tag>
   <elementGuidId>d07fedc0-7a41-48a4-b3b5-bc84e54d4696</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()[contains(.,'Deploy Package')]]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()[contains(.,'Deploy Package')]]</value>
   </webElementProperties>
</WebElementEntity>
