
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String


def static "userdefinedkeywords.fileupload.dd"() {
    (new userdefinedkeywords.fileupload()).dd()
}

def static "userdefinedkeywords.fileupload.uploadFile"(
    	TestObject to	
     , 	String filePath	) {
    (new userdefinedkeywords.fileupload()).uploadFile(
        	to
         , 	filePath)
}

def static "userdefinedkeywords.CurrentDate.call"() {
    (new userdefinedkeywords.CurrentDate()).call()
}

def static "com.kazurayam.ksbackyard.HighlightElement.on"(
    	TestObject testObject	) {
    (new com.kazurayam.ksbackyard.HighlightElement()).on(
        	testObject)
}

def static "com.kazurayam.ksbackyard.HighlightElement.pandemic"() {
    (new com.kazurayam.ksbackyard.HighlightElement()).pandemic()
}

def static "userdefinedkeywords.WriteExcel.refreshBrowser"() {
    (new userdefinedkeywords.WriteExcel()).refreshBrowser()
}

def static "userdefinedkeywords.WriteExcel.clickElement"(
    	TestObject to	) {
    (new userdefinedkeywords.WriteExcel()).clickElement(
        	to)
}

def static "userdefinedkeywords.WriteExcel.demoKey"(
    	String name	) {
    (new userdefinedkeywords.WriteExcel()).demoKey(
        	name)
}
