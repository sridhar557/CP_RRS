<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>User Experience</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>a471f165-a015-4dd6-8e40-ffe2a21698aa</testSuiteGuid>
   <testCaseLink>
      <guid>42bfa570-6352-467d-a383-57d4a15929e4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/User Experience/Cabela_User Experience</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dfa4432d-1103-4943-a75b-425b2e9044df</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/User Experience/Sams Club_User Experience</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>962d28d8-2ab4-45e4-ac38-af8b1ca01362</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/User Experience/United Super Market_User Experience</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>58cb6dd2-67ea-4748-838b-00f98ab5ef9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/User Experience/Walmart_User Experience</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1bcef8af-9d8c-43f6-90c2-ee15e136692a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/User Experience/WESTIN_User Experience</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
