<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Executive Dashboard</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f8d128d2-d55f-4735-988a-be97ffad554f</testSuiteGuid>
   <testCaseLink>
      <guid>c456c398-5ae3-41a2-aab8-ab3e493f4ee8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts - Need Attention</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0131a96b-7c38-48fd-986a-ee294ec5f72a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts Count</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7b2e6ddb-2577-4215-8dc0-c001460ae1ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts - Need Attention</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cd8fc431-002a-4273-ab30-2d5e8361787d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts Count</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f0c7eac7-5610-4383-bd10-2eb6972e18c1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Details Page/Search bar/Global Search</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>d09693ba-29d5-445f-896f-f1200baa596e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/RRS</testDataId>
      </testDataLink>
   </testCaseLink>
</TestSuiteEntity>
