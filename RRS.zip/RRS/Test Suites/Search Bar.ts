<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Search Bar</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>8eb3fe7e-f6a8-4186-a2f1-991330d64800</testSuiteGuid>
   <testCaseLink>
      <guid>d3ac6a28-9743-47bb-bffb-5a79a07b992c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Details Page/Search bar/Global Search</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>dd92704f-0b9a-47f6-9e8f-2e2351a7f951</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Search Bar</testDataId>
      </testDataLink>
   </testCaseLink>
   <testCaseLink>
      <guid>33abd7d5-6eaa-4b36-afa0-fa5b5fe49b1d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Details Page/Search bar/Global Search</testCaseId>
      <testDataLink>
         <combinationType>MANY</combinationType>
         <id>9dffe437-4edb-4686-b4a6-d8e20f88fb44</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Search Bar</testDataId>
      </testDataLink>
   </testCaseLink>
</TestSuiteEntity>
