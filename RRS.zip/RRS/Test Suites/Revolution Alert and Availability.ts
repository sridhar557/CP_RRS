<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Revolution Alert and Availability</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>1d5415ae-04f6-4e9e-9f9a-4b2acc35318c</testSuiteGuid>
   <testCaseLink>
      <guid>772d5f77-815e-43ca-bcba-9d39276fa968</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts - Need Attention</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cf4e73b5-00a0-4ce5-ab1c-83c8d18b1fbe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts Count</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8b0cf854-67b3-4a21-88db-a03b922e2033</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Availability/Revolution Availability - Online Status</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9425a5c6-d01d-4d5d-a436-df86835fe297</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Availability/Revolution Availability</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
