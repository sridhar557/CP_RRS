<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Unit Life</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>a30de91e-2f0b-48f3-85a3-7c1b75df39c9</testSuiteGuid>
   <testCaseLink>
      <guid>4c22750e-aa4a-4321-9df1-969794bb5215</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Unite Life and PM Rolling/United Super Market_Unit Life and PM Rolling</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4f18eb58-7457-47c9-8b0e-6d27d8a27ec5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Unite Life and PM Rolling/WALMART_Unit Life and PM Rolling</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3aedaba6-7238-40ba-bef4-dac49c691417</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Unite Life and PM Rolling/CABELA_Unit Life and PM Rolling</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7aae393a-d2b2-4f80-81d3-08f934180216</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Unite Life and PM Rolling/SAM_Unit Life and PM Rolling</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
