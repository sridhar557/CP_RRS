<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>RRS</description>
   <name>RRS</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>sridhar.padige@techolution.com;</mailRecipient>
   <numberOfRerun>5</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>true</rerunFailedTestCasesOnly>
   <testSuiteGuid>46314a0f-8f63-4435-a385-22c31b874a7e</testSuiteGuid>
   <testCaseLink>
      <guid>aebaa520-68f5-4469-b24b-832a67287b26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Details Page/Search bar/Global Search</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>660cf34a-22b7-46b5-9566-150e9600cd81</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Alert/Revolution Alerts - Need Attention</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>28b396d4-3247-45da-8ad2-982a0d35f667</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Availability/Revolution Availability - Online Status</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6a0868b3-592f-49b7-9228-3f52d214efe1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Details Page/Push and Pull/Push and Pull</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>acee24ad-8fcb-49a8-8867-65c9776c5df2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Details Page/Recent Activity/Recent Activity</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d69c5921-18a5-4cd5-940a-c69ef1934db7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Results Page/Create Package</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f3baf7c8-d990-486a-bd74-3a4cc05324fe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Results Page/Deploy Package for BA</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dc8f4aab-0b83-4413-b1b5-c35e109cd645</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Results Page/Deploy Package</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
