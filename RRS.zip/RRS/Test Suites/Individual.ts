<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Individual</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>5</numberOfRerun>
   <pageLoadTimeout>4</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0e4d84bf-e0e1-4d88-aa03-f012efc40778</testSuiteGuid>
   <testCaseLink>
      <guid>13bacd40-5b33-4766-86e2-644d488b636e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Login with invalid credentials</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2c8ac24b-cb69-43b3-991a-dbcab9ea5f87</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Login with valid credentials</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>97c24182-8292-4319-b81d-e39b699e8191</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/URL Validation</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
