<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Generic</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>1042c22c-5e02-40b2-9616-0f312b10d799</testSuiteGuid>
   <testCaseLink>
      <guid>ce389452-6036-41e4-a7b6-9de51536f4e1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Availability/Revolution Availability - Online Status</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0a7ae364-76e8-4cd5-a2f9-e44f0e5f341e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Revolution Availability/Revolution Availability</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
